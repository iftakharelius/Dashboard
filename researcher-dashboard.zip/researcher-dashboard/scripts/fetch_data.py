#!/usr/bin/env python3
"""
Fetch arXiv, Semantic Scholar, and news data.
Run by GitHub Actions on a schedule; outputs JSON to data/ directory.
"""

import json
import urllib.request
import urllib.parse
import xml.etree.ElementTree as ET
from datetime import datetime, timezone
import os
import sys

# ── Config ────────────────────────────────────────────────────────────────────
ARXIV_CATEGORIES  = os.environ.get("ARXIV_CATEGORIES", "cond-mat").split(",")
ARXIV_KEYWORDS    = os.environ.get("ARXIV_KEYWORDS",   "topological,ARPES,nodal-line,quantum material").split(",")
SEMANTIC_SCHOLAR_ID = os.environ.get("SEMANTIC_SCHOLAR_ID", "")  # set in GitHub Secrets
MAX_PAPERS        = 40
MAX_NEWS          = 12

# ── Helpers ───────────────────────────────────────────────────────────────────
def fetch_url(url, headers=None, timeout=15):
    req = urllib.request.Request(url, headers=headers or {
        "User-Agent": "ResearchDashboard/1.0 (personal use)"
    })
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read().decode("utf-8", errors="replace")

def save(name, data):
    os.makedirs("data", exist_ok=True)
    path = f"data/{name}.json"
    with open(path, "w") as f:
        json.dump(data, f, indent=2)
    print(f"  saved {path}  ({len(data) if isinstance(data, list) else '...'} items)")

# ── arXiv RSS ─────────────────────────────────────────────────────────────────
def fetch_arxiv():
    all_papers = []
    kw_lower = [k.strip().lower() for k in ARXIV_KEYWORDS if k.strip()]

    for cat in ARXIV_CATEGORIES:
        cat = cat.strip()
        url = f"https://export.arxiv.org/rss/{cat}"
        try:
            raw = fetch_url(url)
            root = ET.fromstring(raw)
            ns = {"rss": "http://purl.org/rss/1.0/",
                  "dc":  "http://purl.org/dc/elements/1.1/",
                  "arxiv": "http://arxiv.org/schemas/atom"}
            items = root.findall(".//item")
            for item in items:
                title   = (item.findtext("title") or "").strip()
                link    = (item.findtext("link")  or "").strip()
                desc    = (item.findtext("description") or "").strip()
                authors = (item.findtext("{http://purl.org/dc/elements/1.1/}creator") or "").strip()
                pub     = (item.findtext("pubDate") or "").strip()

                # keyword filter
                blob = (title + " " + desc).lower()
                matched_kws = [k for k in kw_lower if k in blob]

                all_papers.append({
                    "title":       title,
                    "link":        link,
                    "authors":     authors,
                    "abstract":    desc[:400],
                    "category":    cat,
                    "pub_date":    pub,
                    "keyword_hits": matched_kws,
                    "highlighted": len(matched_kws) > 0,
                })
            print(f"  arXiv {cat}: {len(items)} papers")
        except Exception as e:
            print(f"  arXiv {cat} ERROR: {e}", file=sys.stderr)

    # sort: highlighted first, then by date
    all_papers.sort(key=lambda p: (not p["highlighted"], p.get("pub_date", "")))
    all_papers = all_papers[:MAX_PAPERS]
    save("arxiv", all_papers)
    return all_papers

# ── Semantic Scholar ──────────────────────────────────────────────────────────
def fetch_scholar():
    if not SEMANTIC_SCHOLAR_ID:
        print("  Semantic Scholar: no author ID set, skipping")
        save("scholar", {"error": "no author ID configured", "papers": []})
        return

    base = "https://api.semanticscholar.org/graph/v1"
    fields = "name,hIndex,citationCount,paperCount,papers.title,papers.year,papers.citationCount,papers.externalIds"
    url = f"{base}/author/{SEMANTIC_SCHOLAR_ID}?fields={urllib.parse.quote(fields)}"
    try:
        raw = fetch_url(url, headers={
            "User-Agent": "ResearchDashboard/1.0",
        })
        data = json.loads(raw)
        if "error" in data:
            raise ValueError(data["error"])

        papers = sorted(
            data.get("papers", []),
            key=lambda p: p.get("citationCount", 0),
            reverse=True
        )

        result = {
            "name":          data.get("name", ""),
            "hIndex":        data.get("hIndex", 0),
            "citationCount": data.get("citationCount", 0),
            "paperCount":    data.get("paperCount", 0),
            "papers":        papers[:20],
            "fetched_at":    datetime.now(timezone.utc).isoformat(),
        }
        save("scholar", result)
        print(f"  Scholar: h={result['hIndex']}, cites={result['citationCount']}, papers={result['paperCount']}")
    except Exception as e:
        print(f"  Scholar ERROR: {e}", file=sys.stderr)
        save("scholar", {"error": str(e), "papers": []})

# ── Physics News RSS ──────────────────────────────────────────────────────────
NEWS_FEEDS = [
    ("APS Physics",          "https://feeds.aps.org/rss/recent/physics.xml"),
    ("Physical Review Letters","https://feeds.aps.org/rss/recent/prl.xml"),
    ("Nature Physics",       "https://www.nature.com/nphys.rss"),
    ("APS PRL Highlighted",  "https://feeds.aps.org/rss/spotlighting.xml"),
]

def fetch_news():
    all_news = []
    for source, url in NEWS_FEEDS:
        try:
            raw = fetch_url(url)
            root = ET.fromstring(raw)
            items = root.findall(".//item")
            for item in items[:4]:
                title = (item.findtext("title") or "").strip()
                link  = (item.findtext("link")  or "").strip()
                date  = (item.findtext("pubDate") or "").strip()
                desc  = (item.findtext("description") or "").strip()[:200]
                all_news.append({
                    "title":   title,
                    "link":    link,
                    "date":    date,
                    "desc":    desc,
                    "source":  source,
                })
            print(f"  News {source}: {min(len(items),4)} items")
        except Exception as e:
            print(f"  News {source} ERROR: {e}", file=sys.stderr)

    save("news", all_news[:MAX_NEWS])

# ── Meta ──────────────────────────────────────────────────────────────────────
def save_meta():
    save("meta", {
        "fetched_at": datetime.now(timezone.utc).isoformat(),
        "categories": ARXIV_CATEGORIES,
        "keywords":   ARXIV_KEYWORDS,
    })

# ── Main ──────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    print("=== fetching arXiv ===");   fetch_arxiv()
    print("=== fetching Scholar ==="); fetch_scholar()
    print("=== fetching news ===");    fetch_news()
    print("=== saving meta ===");      save_meta()
    print("done.")
